package com.example.labtool;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {


    EditText inputText, outputText;
    Button button;
    String input, output;               //Declare variables to be used by the program

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);




        inputText = (EditText) findViewById(R.id.editText);
        outputText = (EditText) findViewById(R.id.editText2);   //Declare the Text Inputs

        button = (Button) findViewById(R.id.button);    //Declare the FIND Button

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                input = inputText.getText().toString();
                input = input.toLowerCase();

                switch (input){


                    case "formula1": output = "result1";         //To add or edit formulas and adapt the program for your use please add more cases, like the example here
                        break;
                    case "formula2": output = "result2";
                        break;
                    default: output = "Formula Not Found!";
                        break;



                }

                outputText.setText(output);
            }
        });




    }
}
